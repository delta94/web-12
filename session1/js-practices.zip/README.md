# js-practices
Practice 1-3 are for basic Javascript.

Practice 4-5 are for React's FP.

# Instruction
The `/handout` folder is sent to students, should be broken into 2 parts as described above.

**For grading:** paste students' submitted `/handout` folders to `test-paths.json`, then run `benchmark.js`.
